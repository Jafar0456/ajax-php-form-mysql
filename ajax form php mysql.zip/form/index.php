<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> <!-- jQuery library -->

    <title>Php form</title>
</head>
<body>
   <form  id="contactform">
<input type="text" name="name" placeholder="Enter Name"><br><br>
<input type="text" name="email" placeholder="Enter Email"><br><br>

<input type="text" name="password" placeholder="Enter Password"><br><br>

<input type="text" name="phone" placeholder="Enter Phone Number"><br><br>

<input type="date" name="dob" placeholder="Enter Date of Birth"><br><br>
<select name="gender">
<option>Select</option>
<option value="male">Male</option>
<option value="female">Female</option>
<option value="other">Other</option>
</select><br><br>
<input type="submit" value="submit">
<div id="response"></div>
   </form> 
   <script src="ajax.js"></script>
</body>
</html>