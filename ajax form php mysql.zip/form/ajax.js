// ajax.js
$(document).ready(function(){
    // When the form is submitted
    $('#contactform').submit(function(e){
        e.preventDefault(); // Prevents the form from submitting normally

        // Gather the form data
        var formData = $(this).serialize();

        // Perform the AJAX request
        $.ajax({
            type: 'POST', // Method of the request
            url: 'process_form.php', // PHP script to process the form data
            data: formData, // The data to send to the PHP script
            success: function(response) {
                // Display the server response in the #response div
                $('#response').html(response);
            },
            error: function(xhr, status, error) {
                // Handle errors if any
                $('#response').html('Error: ' + error);
            }
        });
    });
});
