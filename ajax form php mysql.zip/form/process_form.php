<?php
include 'connection.php';
if($_SERVER['REQUEST_METHOD']=='POST'){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $phone=$_POST['phone'];
    $dob=$_POST['dob'];
    $gender=$_POST['gender'];
$sql="insert into contactus(name,email,password,phone,dob,gender) 
values('$name','$email','$password','$phone','$dob','$gender')";
$result=mysqli_query($conn,$sql);
if($result){
    echo "data inserted successfully";
}else{
    echo "data not inserted successfully";
}
}
?>