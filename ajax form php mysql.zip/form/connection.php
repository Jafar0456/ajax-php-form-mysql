<?php
$server="localhost";
$username="root";
$password="";
$dbname="form";
$conn=new mysqli($server,$username,$password,$dbname);
if($conn->connect_error){
    die("connection failled".$conn->connect_error);
}
else{
    // echo "connected successfully";
}
?>