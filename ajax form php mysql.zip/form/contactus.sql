-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2024 at 06:02 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `form`
--

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `gender` enum('male','female','other') NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='date';

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`id`, `name`, `email`, `password`, `phone`, `dob`, `gender`, `date`) VALUES
(1, 'jnvhg', 'kjbjdq', 'kjsagdu', 'sdwqiodqw', '2024-11-06', 'other', '2024-11-16 18:37:22'),
(2, 'jafar', 'jafarsiddiquifgp9@gmail.com', 'dgqi', '6394153042', '2024-11-21', 'female', '2024-11-18 09:52:23'),
(3, 'jawedsididqui', 'jawedsiddiqui@423gmail.com', 'ksdi', '5456452', '2024-11-01', 'male', '2024-11-18 09:55:06'),
(4, 'jafar siddiqui', 'jafarsiddiui@gmail.com', 'jah', '876654656876', '0000-00-00', '', '2024-11-18 10:39:24'),
(5, 'jafar siddiqui', 'jafarsiddiquifgp98@gmail.com`', '72136712sjkab', '6394153042', '2024-11-07', 'male', '2024-11-18 10:43:36'),
(6, 'jafar siddiqui', 'jafarsiddiquifgp98@gmail.com`', '72136712sjkab', '6394153042', '2024-11-07', 'other', '2024-11-18 10:44:19'),
(7, 'sonam', 'sonam21@gmail.com', 'fdqwiohq', '876738278', '2024-11-22', 'female', '2024-11-18 10:47:56'),
(8, 'arif', 'arifsiddiqui12@gmail.com', 'bjjsdb@123', '6394153042', '2024-11-22', 'female', '2024-11-18 10:59:51'),
(9, 'arif', 'arifsiddiqui12@gmail.com', 'bjjsdb@123', '6394153042', '2024-11-22', 'male', '2024-11-18 11:02:08'),
(10, 'jafar siddiqi', 'jafarsiddiqquifgp98@gmail.com', 'jafar21', '760744565', '2024-11-24', 'other', '2024-11-20 10:25:45');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
